
JinWu 2017/10/23: Based on PCAN FD disc, remove everything except folder "PCAN-View" and necessary drivers.